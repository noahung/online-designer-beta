<?php
if (!defined('ABSPATH')) exit;
class ODF_Shortcode {
    public static function render_form($atts) {
        $atts = shortcode_atts(array('id' => get_option('odf_default_form_id')), $atts);
        $form_id = sanitize_text_field($atts['id']);
    $api_url = 'https://bahloynyhjgmdndqabhu.supabase.co/functions/v1/api-forms?id=' . urlencode($form_id); // Hardcoded API URL
        $api_key = get_option('odf_api_key');
        if (!$form_id || !$api_key) {
            return '<div style="color:red;">Form configuration missing. Please check plugin settings.</div>';
        }
        $response = wp_remote_get($api_url, array(
            'headers' => array('Authorization' => 'Bearer ' . $api_key)
        ));
        if (is_wp_error($response)) {
            return '<div style="color:red;">Unable to fetch form. Error: ' . esc_html($response->get_error_message()) . '</div>';
        }
        $body = wp_remote_retrieve_body($response);
        $code = wp_remote_retrieve_response_code($response);
        if ($code !== 200) {
            return '<div style="color:red;">Unable to fetch form. API response: <pre>' . esc_html($body) . '</pre></div>';
        }
        // Render as native HTML form, full width/height
        $form = json_decode($body, true);
        if (!$form || !isset($form['id'])) {
            return '<div style="color:red;">Form data is invalid.</div>';
        }
        $name = esc_html($form['name'] ?? 'Form');
        $desc = esc_html($form['description'] ?? '');
        $welcome = esc_html($form['welcome_message'] ?? '');
        $primary_btn_color = esc_html($form['primary_button_color'] ?? '#2193b0');
        $primary_btn_text_color = esc_html($form['primary_button_text_color'] ?? '#fff');
        $secondary_btn_color = esc_html($form['secondary_button_color'] ?? '#eee');
        $secondary_btn_text_color = esc_html($form['secondary_button_text_color'] ?? '#333');
        $theme = esc_html($form['form_theme'] ?? 'generic');

        $html = '<div style="width:100vw;min-height:100vh;display:flex;align-items:center;justify-content:center;background:#f7f9fc;">';
        $html .= '<div style="max-width:600px;width:100%;background:#fff;border-radius:24px;box-shadow:0 4px 24px rgba(0,0,0,0.08);padding:48px 32px;">';
        $html .= '<h2 style="font-size:2.5rem;font-weight:700;margin-bottom:24px;color:#333;">' . $name . '</h2>';
        if ($desc) $html .= '<p style="font-size:1.2rem;color:#555;margin-bottom:24px;">' . $desc . '</p>';
        if ($welcome) $html .= '<div style="margin-bottom:24px;color:#888;">' . $welcome . '</div>';
        $html .= '<form style="width:100%;">';
        $html .= '<!-- Add your form fields here -->';
        $html .= '<button type="submit" style="width:100%;margin-top:32px;padding:18px 0;font-size:1.2rem;font-weight:600;border:none;border-radius:12px;background:' . $primary_btn_color . ';color:' . $primary_btn_text_color . ';box-shadow:0 2px 8px rgba(33,147,176,0.08);cursor:pointer;">Submit</button>';
        $html .= '</form>';
        $html .= '</div></div>';
        return $html;
    }
}
